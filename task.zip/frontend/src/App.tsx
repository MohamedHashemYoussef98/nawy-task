/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";
import React, { useState } from "react";

const App = () => {
  const [data, setData] = useState({
    location: "",
    description: "",
    features: "",
    price: "",
    images: "",
  });

  const onSubmit = async () => {
    const formData = new FormData();
    formData.append("location", data.location);
    formData.append("description", data.description);
    formData.append("features", data.features);
    formData.append("price", data.price);
    formData.append("images", data.images);

    return await axios
      .post(`http://192.168.1.13:3000/api/v1/apartments`, formData)
      .then(() =>
        setData({
          location: "",
          description: "",
          features: "",
          price: "",
          images: "",
        })
      )
      .catch((err) => console.log(err.response.data));
  };

  return (
    <div className="container">
      <h1>Create New Appartment</h1>
      Description:
      <textarea
        value={data.description}
        onChange={(e) =>
          setData((prev: any) => ({ ...prev, description: e.target.value }))
        }
      >
        {data.description}
      </textarea>
      Price:{" "}
      <input
        type="text"
        value={data.price}
        onChange={(e) =>
          setData((prev: any) => ({ ...prev, price: e.target.value }))
        }
      />
      Location:{" "}
      <input
        type="text"
        value={data.location}
        onChange={(e) =>
          setData((prev: any) => ({ ...prev, location: e.target.value }))
        }
      />
      Rooms:{" "}
      <input
        type="text"
        value={data.features.rooms || ""}
        onChange={(e) =>
          setData((prev: any) => ({
            ...prev,
            features: { rooms: e.target.value },
          }))
        }
      />
      Images:{" "}
      <input
        type="file"
        multiple
        onChange={(e) =>
          setData((prev: any) => ({ ...prev, images: e.target.files }))
        }
      />
      <button onClick={onSubmit}>Save</button>
    </div>
  );
};

export default App;
