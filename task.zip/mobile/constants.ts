import { StyleSheet } from "react-native"

export const PRIMARY_COLOR = "#4C33FF"

export const mainStyles = StyleSheet.create({ container: {
    flex: 1,
    backgroundColor: `white`,
  },})