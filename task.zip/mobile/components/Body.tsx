import React from "react";
import { StyleSheet, Text, View } from "react-native";

const Body = () => {
  return <View style={style.container}></View>;
};

const style = StyleSheet.create({
  container: {
    flex: 1,
    shadowColor: "black",
    shadowOpacity: 5,
    elevation: 5,
  },
});

export default Body;
