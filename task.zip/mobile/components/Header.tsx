import React from "react";
import { FlatList, Image, StyleSheet, Text, View } from "react-native";
import { PRIMARY_COLOR } from "../constants";
import { Entypo } from "@expo/vector-icons";

const Header = () => {
  return (
    <View style={style.container}>
      <View style={style.header}>
        <View style={style.left}>
          <Image
            source={{
              uri: "https://www.nawy.com/assets/icons/common/nawy.svg",
            }}
            style={{ borderRadius: 10 }}
          />
        </View>
        <View>
          <Image
            width={60}
            height={60}
            source={{
              uri: "https://imgs.search.brave.com/HgjWgjd4Te-lXp4q3vlTfPz3-EKd-E3w12mFcd5fj1o/rs:fit:500:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5pc3RvY2twaG90/by5jb20vaWQvMTI4/MTk5ODUxOS9waG90/by9wcm9maWxlLXBv/cnRyYWl0LW9mLXdv/bWFuLmpwZz9zPTYx/Mng2MTImdz0wJms9/MjAmYz1NdF9meTNH/SzFka2hyR3BfUGtu/VmpFR2VNTWpfcVNB/QWJIWWtYLWYtMy1r/PQ",
            }}
            style={{ borderRadius: 10 }}
          />
        </View>
      </View>
      <View style={{ display: "flex" }}>
        <FlatList
          data={[{ key: "1" }, { key: "2" }]}
          renderItem={() => {
            return (
              <View
                style={{
                  width: 50,
                  height: 50,
                  borderRadius: 50 / 2,
                  backgroundColor: "blue",
                }}
              ></View>
            );
          }}
          keyExtractor={(item) => item.key}
          horizontal
        />
      </View>
    </View>
  );
};

const style = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    justifyContent: "space-between",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    paddingHorizontal: 25,
    paddingVertical: 10,
    backgroundColor: "red",
  },
  location: {
    fontWeight: "500",
    fontSize: 27,
    marginLeft: 10,
  },
  left: {},
});

export default Header;
