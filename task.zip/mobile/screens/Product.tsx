import {
  ActivityIndicator,
  Dimensions,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import React, { useEffect, useState } from "react";
import { useRoute } from "@react-navigation/native";
import axios from "axios";
import { mainStyles } from "../constants";
import Carousel from "react-native-snap-carousel";

const Product = () => {
  const { params }: any = useRoute();
  const [data, setData] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const width = Dimensions.get("window").width;

  const fetchApartment = async () => {
    return await axios
      .get(`http://192.168.1.13:3000/api/v1/apartments/${params.id}`)
      .then((res) => setData(res.data))
      .catch(() => setIsError(true))
      .finally(() => setIsLoading(false));
  };
  useEffect(() => {
    fetchApartment();
  }, []);
  return (
    <View style={mainStyles.container}>
      {isLoading && (
        <View
          style={{
            flex: 1,
            justifyContent: `center`,
            alignItems: `center`,
          }}
        >
          <ActivityIndicator size={50} color={"blue"} />
        </View>
      )}
      {!isLoading && (
        <View>
          <ScrollView horizontal={true}>
            {data.image_urls.map((v: any, k: number) => (
              <Image
                key={k}
                source={{
                  uri: `http://192.168.1.13:3000${v}`,
                }}
                width={Dimensions.get("screen").width}
                height={Dimensions.get("screen").height * 0.3}
              />
            ))}
          </ScrollView>

          <View
            style={{
              marginLeft: 5,
              marginTop: 10,
              gap: 10,
            }}
          >
            <Text
              style={{
                fontSize: 20,
                fontWeight: "500",
                color: "#666666",
              }}
            >
              Description: {data.description}
            </Text>

            <Text
              style={{
                fontSize: 17,
                fontWeight: "500",
                color: "#666666",
              }}
            >
              {Object.keys(JSON.parse(data.features)).map(
                (v) =>
                  `${v.charAt(0).toUpperCase() + v.slice(1)}: ${
                    JSON.parse(data.features)[v]
                  }`
              )}
            </Text>

            <Text
              style={{
                fontSize: 15,
                fontWeight: `bold`,
              }}
            >
              Location: {data.location}
            </Text>
            <Text
              style={{
                fontSize: 15,
                fontWeight: `bold`,
              }}
            >
              Price: {data.price}$
            </Text>
          </View>
        </View>
      )}
    </View>
  );
};

export default Product;

const styles = StyleSheet.create({});
