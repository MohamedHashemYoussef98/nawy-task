import {
  ActivityIndicator,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useEffect, useState } from "react";
import { mainStyles } from "../constants";
import axios from "axios";
import { useNavigation } from "@react-navigation/native";

const Home = () => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const navigation = useNavigation<any>();

  const fetchApartments = async () => {
    return await axios
      .get(`http://192.168.1.13:3000/api/v1/apartments`)
      .then((res) => setData(res.data))
      .catch(() => setIsError(true))
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    fetchApartments();
  }, []);
  return (
    <View style={mainStyles.container}>
      {isLoading && (
        <View
          style={{
            flex: 1,
            justifyContent: `center`,
            alignItems: `center`,
          }}
        >
          <ActivityIndicator size={50} color={"blue"} />
        </View>
      )}

      {!isLoading && (
        <ScrollView style={mainStyles.container}>
          <View
            style={{
              flexDirection: `row`,
              flexWrap: `wrap`,
              justifyContent: `center`,
              gap: 10,
            }}
          >
            {data.map((v: any, k) => (
              <TouchableOpacity
                key={k}
                style={{
                  width: `47%`,
                }}
                onPress={() =>
                  navigation.push("Product", {
                    id: v.id,
                  })
                }
              >
                <Image
                  source={{
                    uri: `http://192.168.1.13:3000${v.image_urls[0]}`,
                  }}
                  style={{
                    height: 200,
                  }}
                />
                <Text
                  style={{
                    fontSize: 17,
                    fontWeight: "500",
                    color: "#666666",
                  }}
                >
                  {v.description}
                </Text>
                <View
                  style={{
                    flex: 1,
                    flexDirection: `row`,
                    justifyContent: `space-between`,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 15,
                      fontWeight: `bold`,
                    }}
                  >
                    {v.location}
                  </Text>
                  <Text
                    style={{
                      fontSize: 15,
                      fontWeight: `bold`,
                    }}
                  >
                    {v.price}$
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      )}
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({});
