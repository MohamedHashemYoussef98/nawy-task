import * as React from "react";
import { StyleSheet } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import Home from "./screens/Home";
import { mainStyles } from "./constants";
import Product from "./screens/Product";

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <SafeAreaView
      style={[
        mainStyles.container,
        {
          marginTop: 30,
        },
      ]}
    >
      <StatusBar style="auto" backgroundColor="white" />
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen
            name="Home"
            component={Home}
            options={{
              headerShown: false,
            }}
          />
          <Stack.Screen name="Product" component={Product} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({});
