class CreateApartments < ActiveRecord::Migration[7.1]
  def up
    create_table :apartments do |t|
      t.string :location , null: false
      t.decimal :price, default: 0 , precision: 12 , scale: 2 , null: false
      t.json :features
      t.text :description
      t.timestamps
    end

    add_check_constraint :apartments, "price >= 0" , name: "check_minimum_price"
  end

  def down
    drop_table :apartments, if_exists: true
  end
end
