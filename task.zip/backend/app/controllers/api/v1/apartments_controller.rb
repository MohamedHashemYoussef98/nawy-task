class Api::V1::ApartmentsController < ApplicationController
  def index
    @apartments = Apartment.all

    # Construct a response with image URLs
    @apartments_with_image_urls = @apartments.map do |apartment|
      {
        id: apartment.id,
        location: apartment.location,
        features: apartment.features.to_json,
        price: apartment.price,
        description: apartment.description,
        image_urls: apartment.images.map { |image| rails_blob_path(image, only_path: true) }
      }
    end

    render json: @apartments_with_image_urls
  end

  def create
      Apartment.create! apartment_params
  end

  def show
    @apartment = Apartment.find_by! id: params[:id]
    @apartment_with_image_urls =  {
      id: @apartment.id,
      location: @apartment.location,
      features: @apartment.features,
      price: @apartment.price,
      description: @apartment.description,
      image_urls: @apartment.images.map { |image| rails_blob_path(image, only_path: true) }
    }
    render json: @apartment_with_image_urls.to_json
  end

  private
  def apartment_params
    params.permit(:price,:location,:features,:description,images: [])
  end
end
