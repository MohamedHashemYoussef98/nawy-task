class Apartment < ApplicationRecord
  has_many_attached :images
  validates :price, comparison: {greater_than_or_equal_to: 0}
  validates :location, length: {minimum: 3}
end
